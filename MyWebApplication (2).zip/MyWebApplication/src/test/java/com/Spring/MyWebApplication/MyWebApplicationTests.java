package com.Spring.MyWebApplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyWebApplicationTests {

	@Test
	void contextLoads() {
	}

}
